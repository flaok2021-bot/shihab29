طريقة التركيب داخل مشروع Capacitor:

1. انسخ كل مجلدات "mipmap-*" و "values" الموجودة هنا
   إلى المسار التالي بمشروعك:
   android/app/src/main/res/

   (خليها تدمج/تستبدل الموجود بنفس الاسم)

2. تأكد ملف AndroidManifest.xml (بمسار android/app/src/main/)
   يحتوي بالسطر:
   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"
   (موجودة افتراضيًا بمشاريع Capacitor الجديدة)

3. play_store_icon_512.png : استخدمه لرفع التطبيق بمتجر Play (Store Listing).

4. اذا تستخدم GitHub Actions للبناء، بس تأكد هذي الملفات
   موجودة بالمستودع (repo) قبل ما يشتغل الـ workflow، وراح
   تنبني تلقائيًا داخل الـ APK.
